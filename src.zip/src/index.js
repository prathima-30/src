import React from "react";
import ReactDOM from "react-dom";
import Connect from "./connect";
import "./index.css";
ReactDOM.render(
  <Connect/>, 
  document.getElementById("root")
);
