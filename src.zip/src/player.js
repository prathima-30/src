import React, { Component } from "react";
 
class Player extends Component {
  render() {
    return (
      <div>
        <h2>Players</h2>
        <li>Player 1 : </li> 
        <p><input type="text" id="name" name="name" required placeholder="Enter Player 1 Name"></input><br></br></p>
          <li> Player 2 :  </li>
          <p><input type="text" id="name" name="name" required placeholder="Enter Player 2 Name"></input></p>   
      
      </div>
    );
  }
}
 
export default Player;